(function() {

  require(["app"], function(App) {
    return App.initialize();
  });

}).call(this);
